//
//  NASAProjectAPIApp.swift
//  NASAProjectAPI
//
//  Created by Matthew Garlington on 10/30/22.
//

import SwiftUI

@main
struct NASAProjectAPIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
